package screen

import (
	tuiscreen "github.com/Ceinl/plumtree-tui/screen"
)

const (
	DefaultBg    = tuiscreen.DefaultBg
	DefaultFg    = tuiscreen.DefaultFg
	DefaultDecor = tuiscreen.DefaultDecor
)

type Cell = tuiscreen.Cell
type Screen = tuiscreen.Screen

func NewScreen(w, h int) *Screen {
	return tuiscreen.NewScreen(w, h)
}
