package components

import (
	"github.com/Ceinl/plums/internal/ui/tui/layout"
	"github.com/Ceinl/plums/internal/ui/tui/screen"
	"github.com/Ceinl/plums/internal/ui/tui/theme"
)

var (
	infoTabsBg       string
	infoTabsInactive string
	infoTabsActive   string
)

func init() { registerColorRefresher(refreshInfoTabsColors) }

func refreshInfoTabsColors() {
	infoTabsBg = theme.BgBase.Bg()
	infoTabsInactive = theme.TextFaint.Fg()
	infoTabsActive = theme.TextBright.Fg()
}

type InfoTab struct {
	Label  string
	Active bool
}

type InfoTabs struct {
	isDirty bool
	tabs    []InfoTab
	parent  layout.Component
	x, y    int
	w, h    int
	style   layout.Style
}

func NewInfoTabs() *InfoTabs { return &InfoTabs{} }

func (t *InfoTabs) SetTabs(tabs []InfoTab) {
	t.tabs = tabs
	t.isDirty = true
}

func (t *InfoTabs) IsDirty() bool                { return t.isDirty }
func (t *InfoTabs) MakeDirty()                   { t.isDirty = true }
func (t *InfoTabs) ClearDirty()                  { t.isDirty = false }
func (t *InfoTabs) GetStyle() layout.Style       { return t.style }
func (t *InfoTabs) SetParent(p layout.Component) { t.parent = p }
func (t *InfoTabs) SetStyle(st layout.Style)     { t.style = st }

func (t *InfoTabs) Layout(x, y, w, h int) {
	t.x, t.y, t.w, t.h = x, y, w, h
}

func (t *InfoTabs) Render(scr *screen.Screen) {
	if t.w <= 0 || t.h <= 0 {
		return
	}

	bg := t.style.GetBackground()
	if t.parent != nil {
		bg = t.parent.GetStyle().GetBackground()
	}
	if bg == theme.Unset.Bg() {
		bg = infoTabsBg
	}

	for x := 0; x < t.w; x++ {
		scr.Set(t.x+x, t.y, ' ', infoTabsInactive, bg, "")
	}

	cx := t.x + 2
	for i, tab := range t.tabs {
		fg := infoTabsInactive
		if tab.Active {
			fg = infoTabsActive
		}

		if i > 0 {
			for range 3 {
				if cx >= t.x+t.w {
					break
				}
				scr.Set(cx, t.y, ' ', infoTabsInactive, bg, "")
				cx++
			}
		}

		label := tab.Label
		for _, r := range label {
			if cx >= t.x+t.w {
				break
			}
			scr.Set(cx, t.y, r, fg, bg, "")
			cx++
		}
	}
}
