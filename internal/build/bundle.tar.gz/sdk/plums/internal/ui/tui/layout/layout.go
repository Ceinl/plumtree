package layout

import tuilayout "github.com/Ceinl/plumtree-tui/layout"

type (
	UnitType       = tuilayout.UnitType
	JustifyContent = tuilayout.JustifyContent
	AlignItems     = tuilayout.AlignItems
	Direction      = tuilayout.Direction
	Unit           = tuilayout.Unit
	Padding        = tuilayout.Padding
	Style          = tuilayout.Style
	Styler         = tuilayout.Styler
	Component      = tuilayout.Component
)

const (
	UnitPx      = tuilayout.UnitPx
	UnitPercent = tuilayout.UnitPercent
	UnitGrow    = tuilayout.UnitGrow

	JCenter = tuilayout.JCenter
	JLeft   = tuilayout.JLeft
	JRight  = tuilayout.JRight

	ACenter = tuilayout.ACenter
	ATop    = tuilayout.ATop
	ABottom = tuilayout.ABottom
	ALeft   = tuilayout.ALeft
	ARight  = tuilayout.ARight

	Column = tuilayout.Column
	Row    = tuilayout.Row
)
