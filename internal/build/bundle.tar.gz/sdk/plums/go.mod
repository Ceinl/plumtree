module github.com/Ceinl/plums

go 1.26.2

require (
	github.com/Ceinl/plumtree-tui v0.0.0
	github.com/alecthomas/chroma/v2 v2.24.1
	golang.org/x/term v0.42.0
)

require (
	github.com/dlclark/regexp2 v1.12.0 // indirect
	golang.org/x/sys v0.43.0 // indirect
)

replace github.com/Ceinl/plumtree-tui => ../../tui-runtime
