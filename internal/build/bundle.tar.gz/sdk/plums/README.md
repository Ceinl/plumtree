# Plums TUI

A terminal UI component library, salvaged from the Plums AI-agent TUI.
The agent application has been removed; what remains is the reusable TUI base.

## Packages

Under `internal/ui`:

- `tui/screen` — cell buffer / screen rendering
- `tui/layout` — box layout engine
- `tui/theme` — palette and theming
- `tui/components` — div, editor, chatlog, palette, sessions, statusbar, popup, etc.
- `terminal` — raw-mode terminal + tmux helpers

It builds on [`tui-runtime`](../../tui-runtime) and uses `chroma` for syntax
highlighting.

## Development

```bash
make test   # go test -race ./...
make vet
make fmt
```
