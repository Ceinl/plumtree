module github.com/Ceinl/plumtree/tui-runtime

go 1.26.5

require golang.org/x/term v0.45.0

require golang.org/x/sys v0.47.0 // indirect
